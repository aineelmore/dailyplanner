from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Event:
    db = 'events'
    def __init__(self,db_data):
        self.id = db_data['id']
        self.title = db_data['title']
        self.location = db_data['location']
        self.notes = db_data['notes']
        self.date = db_data['date']
        self.user_id = db_data['user_id']
        self.posted_by = ''

    @classmethod
    def save(cls,data):
        query = "INSERT INTO events (title, location, notes, date, user_id) VALUES (%(title)s,%(location)s,%(notes)s,%(date)s,%(user_id)s);"
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def get_all(cls):
        query= "SELECT * FROM events JOIN users ON events.user_id = users.id;"
        results = connectToMySQL(cls.db).query_db(query)
        events = []
        for row in results:
            event = cls(row)
            event.posted_by = row['first_name'] + ' ' + row['last_name']
            events.append( event )
        return events

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM events WHERE id = %(id)s;"
        results = connectToMySQL(cls.db).query_db(query,data)
        return cls( results[0] )

    @classmethod
    def update(cls, data):
        query = "UPDATE events SET title=%(title)s, location=%(location)s,notes=%(notes)s,date=%(date)sWHERE id = %(id)s;"
        return connectToMySQL(cls.db).query_db(query,data)

    @classmethod
    def destroy(cls, data):
        query = "DELETE FROM events WHERE id = %(id)s;"
        return connectToMySQL(cls.db).query_db(query,data)

    @staticmethod
    def validate_event(event):
        is_valid = True
        if (event['title']) == '':
            is_valid = False
            flash("please enter a title")
        if (event['location']) == '':
            is_valid = False
            flash("please add location")
        if (event['notes']) == '':
            is_valid = False
            flash("please add notes")
        if len(event['date']) < 1:
            is_valid = False
            flash("please add a date")
        return is_valid

